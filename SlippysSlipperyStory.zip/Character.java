import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Characters are moveable and have hit boxes
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Character extends AnimatedActor
{
    /**
     * Act - do whatever the Character wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    public Character(String name, int movingCount, int idleCount){
        super(name, movingCount, idleCount);
    }
    
    public void act() 
    {
        super.act();
    }    
}
